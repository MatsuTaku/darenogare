#ifndef _CLIENT_TITLE_H
#define _CLIENT_TITLE_H

#include <stdbool.h>

extern void initTitle();
extern void finalTitle();
extern bool eventTitle();
extern void updateTitle();
extern void drawTitle();

#endif
