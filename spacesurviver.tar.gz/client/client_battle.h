#ifndef _CLIENT_BATTLE_H
#define _CLIENT_BATTLE_H

#include <stdbool.h>

extern int winnerId;

extern bool youWin();

#endif
