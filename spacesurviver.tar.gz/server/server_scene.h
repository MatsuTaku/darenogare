#ifndef _SERVER_SCENE_H_
#define _SERVER_SCENE_H_

#include "../common.h"

extern void sceneInit();
extern bool sceneManagerSync();
extern void changeScene(SCENE);

#endif
