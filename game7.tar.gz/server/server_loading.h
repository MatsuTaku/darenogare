#ifndef _SERVER_LOADING_H_
#define _SERVER_LOADING_H_

#define LOAD_TIME_MIN	2500

extern void initLoading();

#endif
