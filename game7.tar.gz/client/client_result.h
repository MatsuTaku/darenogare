#ifndef _CLIENT_RESULT_H_
#define _CLIENT_RESULT_H_

extern void initResult();
extern void finalResult();
extern bool eventResult();
extern void drawResult();

#endif
